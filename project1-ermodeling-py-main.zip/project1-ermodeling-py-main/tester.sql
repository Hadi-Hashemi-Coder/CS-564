SELECT Count(UserIds)
FROM Users;