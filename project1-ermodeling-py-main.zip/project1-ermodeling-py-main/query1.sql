select count(UserId)
from Users;