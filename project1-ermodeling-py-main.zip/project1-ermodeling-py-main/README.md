Be sure to unpack your ebay_data file into this directory. 
It will not be tracked by git, but be sure to call it `ebay_data`.