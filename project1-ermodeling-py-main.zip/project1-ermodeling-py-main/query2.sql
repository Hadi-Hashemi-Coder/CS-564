select count(UserId)
from Users
Where Location = "New York";